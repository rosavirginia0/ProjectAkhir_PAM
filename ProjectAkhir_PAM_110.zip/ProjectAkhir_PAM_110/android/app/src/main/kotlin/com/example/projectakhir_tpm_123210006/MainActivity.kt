package com.example.projectakhir_tpm_123210006

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
